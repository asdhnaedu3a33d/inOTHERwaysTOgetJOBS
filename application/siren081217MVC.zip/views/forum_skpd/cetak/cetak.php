<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>
<div style="page-break-after: always;">
	<center><h4><?php echo $title_type; ?></h4></center>	
	<table class="full_width collapse" border="1" style="font-size: 5px;">		
		<?php
			echo $forum_skpd;
		?>
	</table>		
</div>