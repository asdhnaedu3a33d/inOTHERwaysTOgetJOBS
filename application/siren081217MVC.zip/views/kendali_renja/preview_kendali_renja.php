<article class="module width_full" style="width: 138%; margin-left: -19%;">
	<header>
	  <h3>Preview Kendali Renja</h3>
	</header>
	<div class="module_content";>
    <div class="scroll">
  		<table class="table-display">	
  			<?php
  				echo $kendali;
  			?>
  		</table>
    </div>
	</div>
	<footer>
		<div class="submit_link">
			<input type="button" value="Kembali" onclick="history.go(-1)">
		</div>
	</footer>
</article>
