<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
	<link href="<?php echo base_url('asset/css/js-image-slider.css');?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url('asset/js/js-image-slider.js');?>" type="text/javascript"></script>
    <link href="<?php echo base_url('asset/css/tooltip.css');?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url('asset/js/tooltip.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('asset/chart/Chart.js'); ?>"></script>

<article class="module width_full">
	<header>
  		<h3>HOME <?php echo $this->session->userdata('nama_unit'); ?></h3>
  	</header>
  	<div class="module_content">
    </div>
</article>