<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<div style="overflow: auto; height: 500px; margin-top: 10px; margin-right: 25px;">
  <table class="table-common">  
    <?php echo $dpa; ?>
  </table>
</div>