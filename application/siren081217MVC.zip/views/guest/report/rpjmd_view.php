<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<div style="overflow: auto; height: 500px; margin-top: 10px;">  
    <?php echo $rpjmd; ?>  
</div>