<article class="module width_full" style="width: 138%; margin-left: -19%;">
	<header>
	  <h3>Preview PPAS</h3>
	</header>
	<div class="module_content";>
		<table class="table-common">
			<thead>
				<tr>
					<th colspan="11" align="center"><?php echo $rka_type; ?></th>
				</tr>
			</thead>
			<?php
				echo $rka;
			?>
		</table>
	</div>
	<footer>
		<div class="submit_link">
			<input type="button" value="Kembali" onclick="history.go(-1)">
		</div>
	</footer>
</article>
