<script>
</script>
<div style="width: 900px">
	<header>
		<h3 style="padding:20px">Evaluasi Renja</h3>
	</header>
    <div class="module_content">
    	<table class="fcari" width="100%">
        	<tbody>
            	<tr>
                    <td width="20%">Periode</td>
                    <td width="80%">
                    </td>
                </tr>	
                <tr>
                    <td width="20%">Tahun</td>
                    <td width="80%">
                    </td>
                </tr>
                <tr>
                    <td width="20%">SKPD</td>
                    <td width="80%">
                    </td>
                </tr>
                <tr>
                    <td>Kode</td>
                    <td width="80%">
                    </td>
                </tr>
                <tr>
                    <td>Kegiatan</td>
                    <td width="80%">
                    </td>
                </tr>
                <tr>
                    <td>Indikator</td>
                    <td width="80%">
                    </td>
                </tr>
            </tbody>
        </table>
		<table class="table-common" width="100%">
        	<tbody>
            <tr>
            	<th colspan="2" width="33%">Target Renstra SKPD Pada Tahun ..... </th>
                <th colspan="2" width="33%">Realisasi Capaian Kinerja Renstra SKPD s./d. Renja SKPD Tahun Lalu (....) </th>
                <th colspan="2" width="33%">Target Kinerja & Anggaran Renja SKPD Tahun Berjalan Yang Dievaluasi ...... </th>
            </tr>
            <tr>
            	<td align="center">K</td>
                <td align="center">Rp.</td>
                <td align="center">K</td>
                <td align="center">Rp.</td>
                <td align="center">K</td>
                <td align="center">Rp.</td>
            </tr>
            <tr>
            	<td align="center">----</td>
                <td align="center">----</td>
                <td align="center">----</td>
                <td align="center">----</td>
                <td align="center">----</td>
                <td align="center">----</td>
            </tr>
            </tbody>
        </table>
        <table class="table-common" width="100%">
        	<thead>
            	<tr>
                	<th colspan="9" align="center">Realisasi Kinerja Pada Triwulan</th>
                </tr>
            </thead>
        	<tbody>
                <tr>
                    <th colspan="2" width="20%">TW 1</th>
                    <th colspan="2" width="20%">TW 2</th>
                    <th colspan="2" width="20%">TW 3</th>
                    <th colspan="2" width="20%">TW 4</th>
                    <th rowspan="2" width="20%">Realisasi Capaian Kinerja dan Anggaran Renja KSPD Yang Dievaluasi</th>
                </tr>
                <tr>
                    <td align="center">K</td>
                    <td align="center">Rp.</td>
                    <td align="center">K</td>
                    <td align="center">Rp.</td>
                    <td align="center">K</td>
                    <td align="center">Rp.</td>
                    <td align="center">K</td>
                    <td align="center">Rp.</td>
                </tr>
                <tr>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                    <td align="center">----</td>
                </tr>
            </tbody>
        </table>
        <table class="fcari" width="100%">
        	<tbody>
            	<tr>
                	<td width="20%" rowspan="2">Tingkat Capaian Kinerja & Anggaran Renja SKPD Yang Dievaluasi (.....)</td>
                    <td width="20%">K</td>
                    <td width="80%"><input type="text" class="test" name="test" readonly="readonly"></td>
                    
                 </tr>
                 <tr>
                	<td bgcolor="#00FF33" width="20%">Rp. </td>
                    <td bgcolor="#00FF33"><input type="text" name="text"/></td>
                </tr>
                <tr>
                	<td width="20%" rowspan="2">Tingkat Capaian Kinerja Dan Realisasi Anggaran Renstra SKPD s/d Tahun ......</td>
                    <td width="20%">K</td>
                    <td width="80%"><input type="text" class="test" name="test" readonly="readonly"></td>
                    
                 </tr>
                 <tr>
                	<td bgcolor="#00FF33" width="20%">Rp. </td>
                    <td bgcolor="#00FF33"><input type="text" name="text"/></td>
                </tr>
                <tr>
                	<td width="20%" rowspan="2">Realisasi Kinerja Dan Anggaran Renstra & SKPD s/d Tahun Berjalan (......)</td>
                    <td width="20%">K</td>
                    <td width="80%"><input type="text" class="test" name="test" readonly="readonly"></td>
                    
                 </tr>
                 <tr>
                	<td bgcolor="#00FF33" width="20%">Rp. </td>
                    <td bgcolor="#00FF33"><input type="text" name="text"/></td>
                </tr>
            </tbody>
        </table>
    </div>
    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>*** Silahkan inputkan data Evaluasi Renja yang sesuai di dalam kolom berwarna hijau</em></p>
	<footer>
		<div class="submit_link">    			
  			<input id="simpan" type="button" value="Simpan">
		</div> 
	</footer>
</div>