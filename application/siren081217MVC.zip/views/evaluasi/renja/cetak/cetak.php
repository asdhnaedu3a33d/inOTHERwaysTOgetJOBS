<div>	
	<?php
		echo $evaluasi;
	?>
</div>