<thead>
				<tr>
					<th rowspan="3" class="no-sort">No</th>	
					<th rowspan="3">KODE</th>
					<th rowspan="3">Urusan/Bidang Urusan Pemerintahan Daerah dan Program / Kegiatan</th>
					<th rowspan="3">Indikator Kinerja Program (Outcome) / Kegiatan(Output)</th>
					<th colspan="2" rowspan="2">Target RPJMD pada Periode RPJMD</th>
					<th colspan="2" rowspan="2">Realisasi Capaian Kinerja RPJMD s/d RKPD Tahun Lalu (<?php echo $ta-1?>)</th>
					<th colspan="2" rowspan="2">Target Kinerja dan Anggaran RKPD Tahun berjalan yang dievaluasi (<?php echo $ta?>)</th>
					<th colspan="8">Realisasi Kinerja Pada Triwulan</th>
					<th colspan="2" rowspan="2">Realisasi Capaian Kinerja dan Anggaran RKPD yang Dievaluasi</th>
					<th colspan="2" rowspan="2">Tingkat Capaian Kinerja dan Realisasi Anggaran RKPD Tahun <?php echo $ta?></th>
					<th colspan="2" rowspan="2">Realisasi Kinerja dan Anggaran RPJMD s/d tahun <?php echo $ta?> (akhir Tahun Pelaksanaan Renja SKPD Tahun <?php echo $ta?>)</th>
					<th colspan="2" rowspan="2">Tingkat Capaian Kinerja dan Realisasi Anggaran RPJMD s/d Tahun <?php echo $ta?> (%)</th>
					<th rowspan="3">Unit SKPD Penanggungjawab</th>
					<th rowspan="3">Keterangan</th>
				</tr>
				<tr>
					<th colspan="2"> I </th>
					<th colspan="2"> II </th>
					<th colspan="2"> III </th>
					<th colspan="2"> IV </th>
				</tr>
				<tr>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
					<th> K </th>
					<th> Rp </th>
				</tr>
			</thead>
			<tbody>	
            	<td colspan="28" align="center">TIDAK ADA DATA.... </td>		
			</tbody>