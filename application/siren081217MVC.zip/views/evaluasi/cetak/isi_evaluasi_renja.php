<thead>
        <tr>
            <th rowspan="3" class="no-sort">No</th>	
            <th rowspan="3">KODE</th>
            <th rowspan="3">Urusan/Bidang Urusan Pemerintahan Daerah dan Program / Kegiatan</th>
            <th rowspan="3">Indikator Kinerja Program (Outcome) / Kegiatan(Output)</th>
            <th colspan="2" rowspan="2">Target Renstra SKPD pada Tahun <?php echo $ta?> (Akhir Periode Renstra SKPD)</th>
            <th colspan="2" rowspan="2">Realisasi Capaian Kinerja Renstra SKPD s.d. Renja SKPD Tahun Lalu (<?php echo $ta-1?>)</th>
            <th colspan="2" rowspan="2">Target Kinerja dan Anggaran Renja SKPD Tahun berjalan yang dievaluasi (<?php echo $ta?>)</th>
            <th colspan="8">Realisasi Kinerja Pada Triwulan</th>
            <th colspan="2" rowspan="2">Realisasi Capaian Kinerja dan Anggaran Renja SKPD yang Dievaluasi (<?php echo $ta?>)</th>
            <th colspan="2" rowspan="2">Tingkat Capaian Kinerja dan Realisasi Anggaran Renja SKPD Tahun <?php echo $ta?></th>
            <th colspan="2" rowspan="2">Realisasi Kinerja dan Anggaran Renstra SKDP s/d tahun <?php echo $ta?> (akhir Tahun Pelaksanaan Renja SKPD Tahun <?php echo $ta?>)</th>
            <th colspan="2" rowspan="2">Tingkat Capaian Kinerja dan Realisasi Anggaran Renstra SKPD s/d Tahun <?php echo $ta?> (%)</th>
            <th rowspan="3">Unit SKPD Penanggungjawab</th>
            <th rowspan="3">Keterangan</th>
        </tr>
        <tr>
            <th colspan="2"> I </th>
            <th colspan="2"> II </th>
            <th colspan="2"> III </th>
            <th colspan="2"> IV </th>
        </tr>
        <tr>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
            <th> K </th>
            <th> Rp </th>
        </tr>
    </thead>
    <tbody>	
    <tr>
    	<td colspan="28" align="center">TIDAK ADA DATA.... </td>
    </tr>
    </tbody>