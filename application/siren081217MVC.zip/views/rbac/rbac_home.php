<html>
<head>
</head>
<body>
<a href="<?php echo site_url("rbac/rbac_roles"); ?>">RBAC Roles</a>
<br />
<a href="<?php echo site_url('rbac/rbac_permission'); ?>">RBAC Permission</a>
<br />
<a href="<?php echo site_url('rbac/rbac_role_permission'); ?>">RBAC Role Permission</a>
<br />
<a href="<?php echo site_url('rbac/rbac_user_role'); ?>">RBAC User Role</a>
</body>
</html>