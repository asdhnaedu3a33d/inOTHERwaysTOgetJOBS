<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>
<div>	
	<table class="full_width border" style="font-size: 8px;">
		<tr>
			<th colspan="12" align="center"><?php echo $rkpd_type; ?></th>
		</tr>
		<?php
			echo $rkpd;
		?>
	</table>		
</div>