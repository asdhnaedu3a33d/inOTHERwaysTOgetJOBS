<div align="center">Tabel Capaian Aksi Program</div>
<table border="1" style="border-collapse: collapse"  width="100%">
	<thead>
		<tr>
			<th>NO.</th>
			<th>PROGRAM</th>
			<th>BULAN</th>
			<th>URAIAN KINERJA</th>
			<th>BOBOT</th>
			<th>TARGET</th>
			<th>REALISASI AKSI</th>
			<th>CAPAIAN (%)</th>
			<!-- <th>CAPAIAN KOMULATIF (%)</th> -->
		</tr>
	</thead>
	<tbody>
		<?php
		// print_r($aksi);
			$i = 1;
			foreach ($aksi as $key => $row) {
				$rencana_aksi = $this->m_dpa->get_cetak_rencana_program($row->id, 0)->result();
				$count_per_aksi = $this->m_dpa->get_cetak_rencana_program($row->id)->num_rows();

				foreach ($rencana_aksi as $key2 => $row2) {
					 $aksi_per_bulan = $this->m_dpa->get_cetak_rencana_program($row2->id_dpa_prog_keg,$row2->bulan)->result();
					 $count_per_bulan = count($aksi_per_bulan);

					 foreach ($aksi_per_bulan as $key3 => $row3) {
					 	$for_capaian = formatting::currency(($row3->capaian/$row3->target)*100);	
		?>
			<tr>
				<?php if ( $key2 == 0 && $key3 == 0) { ?>
					<td valign="top" rowspan="<?php echo $count_per_aksi ?>"><?php echo $i; ?></td>
					<td valign="top" rowspan="<?php echo $count_per_aksi ?>"><?php echo $row->kd_urusan.".".$row->kd_bidang.".".$row->kd_program." ".$row->nama_prog_or_keg; ?></td>
				<?php } ?>
				<?php if ( $key3 == 0) { ?>
					<td valign="top" rowspan="<?php echo $count_per_bulan ?>">BLN <?php echo $row2->bulan; ?></td>
				<?php } ?>
					<td valign="top"><?php echo $row3->aksi; ?></td>
					<td valign="top"><?php echo number_format($row3->bobot, 2, ',', '.'); ?></td>
					<td valign="top"><?php echo number_format($row3->target, 2, ',', '.'); ?></td>
					<td valign="top"><?php echo number_format($row3->capaian, 2, ',', '.'); ?></td>
					<td valign="top"><?php echo $for_capaian; ?></td>
					<!-- <td><?php echo formatting::currency(($row3->bobot*$for_capaian)/100); ?></td> -->
			</tr>	
		<?php }}$i++; } ?>
	</tbody>
</table>