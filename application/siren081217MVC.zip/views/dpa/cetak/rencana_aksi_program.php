<div align="center">Tabel Rencana Aksi Program</div>
<table border="1" style="border-collapse: collapse"  width="100%">
	<thead>
		<tr>
			<th>NO.</th>
			<th>PROGRAM</th>
			<th>UKURAN KEBERHASILAN</th>
			<th>BULAN</th>
			<th>URAIAN KINERJA</th>
			<th>BOBOT</th>
			<th>TARGET</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$i = 1;
			foreach ($aksi as $key => $row) {
				$rencana_aksi = $this->m_dpa->get_cetak_rencana_program($row->id, 0)->result();
				$count_per_aksi = $this->m_dpa->get_cetak_rencana_program($row->id)->num_rows();
				$indikator = $this->m_dpa->get_indikator_prog_keg($row->id, true, true);

				foreach ($rencana_aksi as $key2 => $row2) {
					 $aksi_per_bulan = $this->m_dpa->get_cetak_rencana_program($row2->id_dpa_prog_keg,$row2->bulan)->result();
					 $count_per_bulan = count($aksi_per_bulan);

					 foreach ($aksi_per_bulan as $key3 => $row3) {	 	
		?>
			<tr>
				<?php if ( $key2 == 0 && $key3 == 0) { ?>
					<td valign="top" rowspan="<?php echo $count_per_aksi ?>"><?php echo $i; ?></td>
					<td valign="top" rowspan="<?php echo $count_per_aksi ?>"><?php echo $row->kd_urusan.".".$row->kd_bidang.".".$row->kd_program." ".$row->nama_prog_or_keg; ?></td>
					<td valign="top" rowspan="<?php echo $count_per_aksi; ?>">
						<?php 
							foreach ($indikator as $row_indik) {
								echo $row_indik->indikator." ".$row_indik->target." ".$row_indik->nama_value."<p>";
							}
						?>
					</td>
				<?php } ?>
				<?php if ( $key3 == 0) { ?>
					<td valign="top" rowspan="<?php echo $count_per_bulan ?>">BLN <?php echo $row2->bulan; ?></td>
				<?php } ?>
					<td valign="top"><?php echo $row3->aksi; ?></td>
					<td valign="top"><?php echo number_format($row3->bobot, 2, ',', '.'); ?></td>
					<td valign="top"><?php echo number_format($row3->target, 2, ',', '.'); ?></td>
			</tr>	
		<?php }}$i++; } ?>
	</tbody>
</table>