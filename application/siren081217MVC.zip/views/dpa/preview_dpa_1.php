<article class="module width_full" style="width: 300%; margin-left: -19%;">
	<header>
	  <h3>Preview DPA</h3>
	</header>
	<div class="module_content";>
		<div class="scroll">
		<table class="table-common" width="200%">
			<thead>
				<tr>
					<th colspan="19" align="center"><?php echo $dpa_type; ?></th>
				</tr>
			</thead>
			<?php
				echo $dpa;
			?>
		</table>
	</div>
	</div>
	<footer>
		<div class="submit_link">
			<input type="button" value="Kembali" onclick="history.go(-1)">
		</div>
	</footer>
</article>
