<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>
<div>
	<table class="full_width border" style="font-size: 11px;">
    <thead>
            <tr>
                <th rowspan="2" colspan="4">KODE</th>
                <th rowspan="2">PROGRAM DAN KEGIATAN</th>
                <th colspan="3">ANGGARAN</th>
                <th colspan="4">KELOMPOK INDIKATOR KINERJA PROGRAM (OUTCOME) / INDIKATOR KINERJA KEGIATAN (OUTPUT)</th>
                <th rowspan="2">KET.</th>
            </tr>
            <tr>
                <th>RENCANA (Rp.)</th>
                <th>REALISASI (Rp.)</th>
                <th>CAPAIAN IK (%)</th>
                <th>INDIKATOR/SATUAN</th>
                <th>RENCANA</th>
                <th>REALISASI</th>
                <th>CAPAIAN IK</th>
            </tr>
          </thead>
		<?php
			echo $cik;
		?>
	</table>		
</div>