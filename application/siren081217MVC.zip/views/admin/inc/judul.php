<header id="header">
        <hgroup id="judul">
            <img src="<?php echo base_url();?>asset/images/admin.png"/>
            <h2 class="namauniv"><a href="index.html">Universitas Udayana</a></h1>
            <h1 class="namasistem">Sistem Management Keuangan</h2>
        </hgroup>
    </header> <!-- end of header bar -->