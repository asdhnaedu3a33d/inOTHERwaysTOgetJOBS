	<footer id="halaman">
    copyright &copy; 2012 by Divinkom Udayana
    </footer>