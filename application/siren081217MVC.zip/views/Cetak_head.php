

        <table  style="margin: auto;" border="0" width="100%" align="center">
          <tbody>
            <tr>
              <th  style="padding-right: 10px;" width="20%" rowspan="4" ><img height="30px" src="<?php echo base_url().'asset\themes\modify-style\images\template\klk.png'; ?>"> </th> 
              <th width="60%" align="center" style="font-size:16px; font-family: 'Times New Roman', Georgia, Serif;" ><strong>BADAN PERENCANAAN, PENELITIAN DAN PENGEMBANGAN <br> Pemerintah Kabupaten Klungkung</strong> </th>
              <th width="20%" rowspan="4"   > 
              <div  style="height:20px;">
               <?php if(!empty($qr['qrcode'])){echo $qr['qrcode'];} ?>
               </div>
               </th>
              
         </tr>
            
            <tr>
              <td align="center" style="font-size:10px;">  </td>
            </tr>
            <tr>
              <td align="center" style="font-size:10px;"> </td>
            </tr>
            <tr>
              <td colspan="3" > &emsp; </td>
            </tr>
            <tr>
              <td colspan="3" > <hr style="color: '#000066'; ">  </td>
            </tr>
          </tbody>
          </table>  

 



