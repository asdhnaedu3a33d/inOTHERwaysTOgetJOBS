
<article class="module width_full">
	<div class="module_content">
		<?php $text = str_replace("_", " ", $pesan) ?>
 		<h3><?php echo $text; ?></h3>
		<br>
	</div>
</article>
