<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>


<div >
	<p> <strong>3.Tabel Kebijakan Umum Renstra </strong> </p>
	<table  class="full_width collapse" border="1" style="font-size: 15px;">

		<?php
			echo $renstra;
		?>
	</table>
</div>
