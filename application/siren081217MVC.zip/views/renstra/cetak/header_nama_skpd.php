<tbody class="print-no-border">
	<tr>		
		<td class="print-no-border">SKPD</td>
		<td class="print-no-border">:</td>
		<td class="print-no-border"><?php echo $skpd_visi->nama_skpd; ?></td>
	</tr>
</tbody>