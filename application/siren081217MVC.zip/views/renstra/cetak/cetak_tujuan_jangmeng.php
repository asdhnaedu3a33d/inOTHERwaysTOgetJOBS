<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>





<div >
	<p> <strong>1. Tabel Tujuan Jangka Menengah </strong> </p>
	<table  class="full_width collapse" border="1" style="font-size: 5px;">

		<?php
			echo $header_tujuan_gabung;
		?>
	</table>
</div>
