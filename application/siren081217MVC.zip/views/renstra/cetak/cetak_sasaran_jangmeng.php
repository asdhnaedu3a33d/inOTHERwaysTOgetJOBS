<style type="text/css">
	.no-border{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>


<div >
	<p> <strong>2. Tabel Sasaran Jangka Menengah </strong> </p>
	<table  class="full_width collapse" border="1" style="font-size: 5px;">

		<?php
			echo $header_sasaran_gabung;
		?>
	</table>
</div>
