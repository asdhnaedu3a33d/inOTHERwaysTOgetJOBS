
<div >
	<?php
		echo $cetak;
	?>
</div>
