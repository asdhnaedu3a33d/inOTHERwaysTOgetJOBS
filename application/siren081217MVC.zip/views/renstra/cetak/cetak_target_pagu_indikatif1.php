<style type="text/css">
	table td{
		vertical-align: top;
	}
</style>

<div >
	<p> <strong>4. Tabel Target & Pagu Indikatif Program / Kegiatan </strong> </p>
<table border="1"  style="border-collapse: collapse"  width="100%"  >
		<?php
			echo $renstra;
		?>
</table>
</div>

