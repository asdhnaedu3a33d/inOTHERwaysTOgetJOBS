<style type="text/css">
	table{
		border-collapse: collapse;
	}

	td.print-no-border{
		border: none;
	}
</style>
<div >
	<center><h4><?php echo $musrenbang_type; ?></h4></center>	
	<table class="full_width collapse" border="1px" style="font-size: 11px;">		
		<?php
			echo $musrenbang;
		?>
	</table>		
</div>